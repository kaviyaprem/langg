from flask import Flask, render_template, redirect, url_for, request, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config
import openai

app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)

openai.api_key = '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'  # Replace with your OpenAI API key

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    education = db.Column(db.String(50), nullable=False)
    skills = db.Column(db.String(200), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['education'] = user.education
            session['skills'] = user.skills
            return redirect(url_for('chat'))
        flash('Invalid email or password.')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        education = request.form['education']
        skills = request.form.getlist('skills')
        skills_str = ', '.join(skills)
        user = User(email=email, education=education, skills=skills_str)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/chat')
def chat():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('chat.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_input = request.form['user_input']
    education = session['education']
    skills = session['skills']
    prompt = f"As a {education}, I want to improve my {skills}. Please give some suggestions, corrections, and feedback. Do not answer anything other than English language learning related queries.\nUser: {user_input}\nBot:"

    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=150
    )

    return response.choices[0].text.strip()

if __name__ == '__main__':
    app.run(debug=True)
